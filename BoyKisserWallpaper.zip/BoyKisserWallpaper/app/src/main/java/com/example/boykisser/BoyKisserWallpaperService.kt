package com.example.boykisser

import android.content.res.Configuration
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.*
import kotlin.random.Random

/**
 * Порт эмиттера частиц из iOS-обоев (.tendies):
 * birthRate 21/с, lifetime 13 с, velocity 300±150, scale 0.67, spin 2.76±2.79 рад/с.
 * Фон: белый (светлая тема) / чёрный (тёмная тема).
 */
class BoyKisserWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = KisserEngine()

    private class Particle(
        var x: Float, var y: Float, val vx: Float, val vy: Float,
        var rot: Float, val spin: Float, val life: Float
    ) { var age = 0f }

    private inner class KisserEngine : Engine() {
        // параметры из оригинала (координаты документа 3176x3176)
        private val doc = 3176f
        private val birthRate = 21f
        private val lifetime = 13f
        private val velocity = 300f
        private val velocityRange = 150f
        private val baseScale = 0.67f
        private val spin = 2.76f
        private val spinRange = 2.79f
        private val spread = 1.40f

        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val matrix = Matrix()
        private val particles = ArrayList<Particle>()
        private var bmp: Bitmap? = null

        private var w = 1
        private var h = 1
        private var visible = false
        private var last = 0L
        private var acc = 0f

        private val frame = object : Runnable {
            override fun run() {
                step(); draw()
                if (visible) handler.postDelayed(this, 16)
            }
        }

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            val o = BitmapFactory.Options().apply { inScaled = false }
            bmp = BitmapFactory.decodeResource(resources, R.drawable.boykisser, o)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            w = width; h = height
            super.onSurfaceChanged(holder, format, width, height)
            draw()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(frame)
            if (v) { last = SystemClock.uptimeMillis(); handler.post(frame) }
        }

        override fun onDestroy() {
            handler.removeCallbacks(frame)
            super.onDestroy()
        }

        // движение масштабируется по длинной стороне экрана, размер картинки по короткой
        private fun moveUnit() = max(w, h) / doc
        private fun sizeUnit() = min(w, h) / doc

        private fun spawn() {
            val mu = moveUnit()
            // эмиттер за правым нижним углом экрана, как в оригинале
            val sx = w + 150f * mu + Random.nextFloat() * 300f * mu
            val sy = h + 150f * mu + Random.nextFloat() * 230f * mu
            val dir = atan2(-sy, -sx) + (Random.nextFloat() - 0.5f) * spread
            val speed = (velocity + (Random.nextFloat() * 2 - 1) * velocityRange) * mu
            particles += Particle(
                sx, sy, cos(dir) * speed, sin(dir) * speed,
                Random.nextFloat() * (2f * PI.toFloat()),
                spin + (Random.nextFloat() * 2 - 1) * spinRange,
                lifetime
            )
        }

        private fun step() {
            val now = SystemClock.uptimeMillis()
            val dt = ((now - last) / 1000f).coerceIn(0f, 0.1f)
            last = now
            acc += dt * birthRate
            while (acc >= 1f) { spawn(); acc -= 1f }
            val it = particles.iterator()
            while (it.hasNext()) {
                val p = it.next()
                p.age += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.spin * dt
                if (p.age > p.life) it.remove()
            }
        }

        private fun draw() {
            val b = bmp ?: return
            val holder = surfaceHolder
            val c = try { holder.lockCanvas() } catch (e: Exception) { null } ?: return
            try {
                val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                        Configuration.UI_MODE_NIGHT_YES
                c.drawColor(if (dark) Color.BLACK else Color.WHITE)
                val s = baseScale * sizeUnit()
                for (p in particles) {
                    matrix.reset()
                    matrix.postTranslate(-b.width / 2f, -b.height / 2f)
                    matrix.postRotate(Math.toDegrees(p.rot.toDouble()).toFloat())
                    matrix.postScale(s, s)
                    matrix.postTranslate(p.x, p.y)
                    c.drawBitmap(b, matrix, paint)
                }
            } finally {
                holder.unlockCanvasAndPost(c)
            }
        }
    }
}
