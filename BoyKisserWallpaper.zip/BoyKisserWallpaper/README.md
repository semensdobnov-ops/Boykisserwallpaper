# Boykisser Live Wallpaper (порт .tendies -> Android)

## Сборка APK
A) Android Studio: File -> Open -> эта папка -> Build -> Build APK(s).
   Результат: app/build/outputs/apk/debug/app-debug.apk
B) Без Android Studio: залейте папку в GitHub-репозиторий,
   вкладка Actions -> Build APK -> скачайте артефакт boykisser-apk.

## Установка
Установите APK, откройте приложение "Boykisser" -> откроется экран установки обоев.
Или: Настройки -> Обои и стиль -> Живые обои -> Boykisser.
